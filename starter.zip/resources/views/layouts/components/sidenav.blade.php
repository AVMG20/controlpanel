<nav id="sidebarMenu" class="sidebar d-lg-block bg-gray-800 text-white collapse" data-simplebar>
    <div class="sidebar-inner px-2 pt-3">
        @include('layouts.components.responsive-topbar')
        @include('layouts.components.navigation')
    </div>
</nav>
