<!-- Sweet alert 2 -->
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if($message = Session::get('success')): ?>
    <script defer>
        //success message
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 2000,
            timerProgressBar: false,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })

        Toast.fire({
            icon: 'success',
            title: '<?php echo e($message); ?>'
        })
    </script>
<?php endif; ?>

<script>
    //delete confirm
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
</script>
<?php /**PATH /var/www/controlpanel/resources/views/layouts/components/scripts.blade.php ENDPATH**/ ?>