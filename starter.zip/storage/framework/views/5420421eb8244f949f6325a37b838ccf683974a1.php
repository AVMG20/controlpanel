
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.roles.write")): ?>
                            <a data-content="<?php echo e(__('Edit')); ?>" data-toggle="popover" data-trigger="hover" data-placement="top" href="<?php echo e(route("admin.users.edit", $user)); ?>" class="btn btn-sm btn-info"><i
                                    class="fa fas fa-edit"></i></a>
                            <form class="d-inline" method="post" action="<?php echo e(route("admin.users.destroy", $user)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("DELETE"); ?>
                                <button type="submit" class="btn btn-sm btn-danger confirm"><i
                                        class="fa fas fa-trash"></i></button>
                            </form>
                        <?php endif; ?><?php /**PATH /var/www/controlpanel/storage/framework/views/7428ca73e9351c2164ca0aa34e969f98bf0aeb73.blade.php ENDPATH**/ ?>