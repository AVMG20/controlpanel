<?php $__env->startSection('content'); ?>
    <div class="main py-4">

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.roles.write')): ?>
            <div class="d-flex justify-content-end my-3">
                <a href="<?php echo e(route('admin.roles.create')); ?>" class="btn btn-primary"><i
                        class="fa fas fa-shield-alt pe-2"></i><?php echo e(__('Create role')); ?></a>
            </div>
        <?php endif; ?>

        <div class="card card-body border-0 shadow table-wrapper table-responsive">
            <h2 class="mb-4 h5"><?php echo e(__('Roles')); ?></h2>

            <?php echo $html->table(); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo $html->scripts(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/controlpanel/resources/views/admin/roles/index.blade.php ENDPATH**/ ?>