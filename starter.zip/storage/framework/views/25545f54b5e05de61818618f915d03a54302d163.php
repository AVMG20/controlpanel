<ul class="nav flex-column pt-3 pt-md-0">
    <li class="nav-item">
        <a href="<?php echo e(route('home')); ?>" class="nav-link d-flex align-items-center">
            <span class="sidebar-icon me-3">
                <img src="<?php echo e(asset('images/brand/light.svg')); ?>" height="20" width="20" alt="Volt Logo">
            </span>
            <span class="mt-1 ms-1 sidebar-text">
                Volt Laravel
            </span>
        </a>
    </li>

    <li class="nav-item <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('home')); ?>" class="nav-link">
            <span class="sidebar-icon">
                <svg class="icon icon-xs me-2" fill="currentColor" viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z"></path>
                    <path d="M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z"></path>
                </svg>
            </span>
            <span class="sidebar-text"><?php echo e(__('Dashboard')); ?></span>
        </a>
    </li>

    <hr>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.users.read')): ?>
    <li class="nav-item <?php echo e(request()->routeIs('admin.users.index') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.users.index')); ?>" class="nav-link">
            <span class="sidebar-icon me-3">
                <i class="fas fa-user-alt fa-fw"></i>
            </span>
            <span class="sidebar-text"><?php echo e(__('Users')); ?></span>
        </a>
    </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.roles.read')): ?>
    <li class="nav-item <?php echo e(request()->routeIs('admin.roles.index') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.roles.index')); ?>" class="nav-link">
            <span class="sidebar-icon me-3">
               <i class="fas fa-shield-alt fa-fw"></i>
            </span>
            <span class="sidebar-text"><?php echo e(__('Roles')); ?></span>
        </a>
    </li>
    <?php endif; ?>





















































</ul>
<?php /**PATH /var/www/controlpanel/resources/views/layouts/components/navigation.blade.php ENDPATH**/ ?>