
                        @can("admin.roles.write")
                            <a href="{{route("admin.roles.edit", $role)}}" class="btn btn-sm btn-info"><i
                                    class="fa fas fa-edit"></i></a>
                            <form class="d-inline" method="post" action="{{route("admin.roles.destroy", $role)}}">
                                @csrf
                                @method("DELETE")
                                <button type="submit" class="btn btn-sm btn-danger confirm"><i
                                        class="fa fas fa-trash"></i></button>
                            </form>
                        @endcan