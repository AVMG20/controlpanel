
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.roles.write")): ?>
                            <a data-tooltip="edit" href="<?php echo e(route("admin.users.edit", $user)); ?>" class="btn btn-sm btn-info"><i
                                    class="fa fas fa-edit"></i></a>
                            <form class="d-inline" method="post" action="<?php echo e(route("admin.users.destroy", $user)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("DELETE"); ?>
                                <button type="submit" class="btn btn-sm btn-danger confirm"><i
                                        class="fa fas fa-trash"></i></button>
                            </form>
                        <?php endif; ?><?php /**PATH /var/www/controlpanel/storage/framework/views/668ce6df2c716402ad1427cdd59d40bd8858438a.blade.php ENDPATH**/ ?>