<?php $__env->startSection('content'); ?>
    <div class="main py-4">

        <div class="card card-body border-0 shadow table-wrapper table-responsive">
            <h2 class="mb-4 h5"><?php echo e(isset($role) ?  __('Edit role') : __('Create role')); ?></h2>

            <form method="post"
                  action="<?php echo e(isset($role) ? route('admin.roles.update', $role->id) : route('admin.roles.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php if(isset($role)): ?>
                    <?php echo method_field('PATCH'); ?>
                <?php endif; ?>

                <div class="row">
                    <div class="col-lg-6">

                        <div class="form-group mb-3">
                            <label for="name"><?php echo e((__('Name'))); ?></label>
                            <input value="<?php echo e(old('name', isset($role) ? $role->name : '')); ?>" id="name" name="name"
                                   type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group mb-3">
                            <label for="color"><?php echo e((__('Badge color'))); ?></label>
                            <input value="<?php echo e(old('color', isset($role) ? $role->color : '')); ?>" id="color" name="color"
                                   type="color" class="form-control <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>

                    <div class="col-lg-6">

                        <div class="form-group mb-3">
                            <label for="permissions"><?php echo e((__('Permissions'))); ?></label>
                            <select style="height: 180px;" class="form-control form-select-lg" multiple name="permissions[]"
                                    id="permissions">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if(isset($role) && $role->permissions->contains($permission)): ?> selected
                                            <?php endif; ?> value="<?php echo e($permission->id); ?>"><?php echo e($permission->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                    </div>
                </div>

                <div class="form-group d-flex justify-content-end mt-3">
                    <button name="submit" type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
                </div>
            </form>

        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/controlpanel/resources/views/admin/roles/edit.blade.php ENDPATH**/ ?>