
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.roles.write")): ?>
                            <td style="width: 200px;">
                                <a href="<?php echo e(route("admin.roles.edit", $role)); ?>" class="btn btn-sm btn-info"><i
                                        class="fa fas fa-edit"></i></a>
                                <form class="d-inline" method="post" action="<?php echo e(route("admin.roles.destroy", $role)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("DELETE"); ?>
                                    <button type="submit" class="btn btn-sm btn-danger confirm"><i
                                            class="fa fas fa-trash"></i></button>
                                </form>
                            </td>
                        <?php endif; ?><?php /**PATH /var/www/controlpanel/storage/framework/views/cf1e6c05611cabe6e2eb78e89803a5127370cae9.blade.php ENDPATH**/ ?>