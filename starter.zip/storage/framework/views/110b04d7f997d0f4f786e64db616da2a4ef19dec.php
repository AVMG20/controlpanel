
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.roles.write")): ?>
                            <a title="<?php echo e('Edit'); ?>" href="<?php echo e(route("admin.users.edit", $user)); ?>" class="btn btn-sm btn-info"><i
                                    class="fa fas fa-edit"></i></a>
                            <form class="d-inline" method="post" action="<?php echo e(route("admin.users.destroy", $user)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("DELETE"); ?>
                                <button title="<?php echo e('Delete'); ?>" type="submit" class="btn btn-sm btn-danger confirm"><i
                                        class="fa fas fa-trash"></i></button>
                            </form>
                        <?php endif; ?><?php /**PATH /var/www/controlpanel/storage/framework/views/a6ac45295d3fa2b581f71cc39d862b60d08d61df.blade.php ENDPATH**/ ?>