
        function() {
            $('.confirm').click(function(event) {
                var form =  $(this).closest("form");
                var name = $(this).data("delete-confirm");
                event.preventDefault();
                Swal.fire({
                    title: "<?php echo e(__('Are you sure you want to delete this record?')); ?>",
                    text: "<?php echo e(__('If you delete this, it will be gone forever.')); ?>",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonText: "<?php echo e(__("Yes, delete it!")); ?>",
                    cancelButtonText: "<?php echo e(__('No, cancel!')); ?>",
                    reverseButtons: false
                })
                    .then((e) => {
                        if (e.value) {
                            form.submit();
                        }
                    });
                });
            }<?php /**PATH /var/www/controlpanel/storage/framework/views/3d8a5ab204096d6c71cda83bb9ab4e134091563c.blade.php ENDPATH**/ ?>