
      console.log(1)
        function() {
            console.log(1)
            $('confirm').click(function(event) {
                var form =  $(this).closest("form");
                var name = $(this).data("delete-confirm");
                event.preventDefault();
                Swal.fire({
                    title: "<?php echo e(__('re you sure you want to delete this record?'); ?>",
                    text: "<?php echo e(__('f you delete this, it will be gone forever.'); ?>",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonText: "<?php echo e(__("Yes, delete it!")); ?>",
                    cancelButtonText: "<?php echo e(__('o, cancel!'); ?>",
                    reverseButtons: false
                })
                    .then((e) => {
                        if (e.value) {
                            form.submit();
                        }
                    });
                });
            }<?php /**PATH /var/www/controlpanel/storage/framework/views/3c09d539703d378686750df93ad4171c736e9f32.blade.php ENDPATH**/ ?>