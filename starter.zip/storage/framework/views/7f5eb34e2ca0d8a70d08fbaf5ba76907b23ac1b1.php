
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.roles.write")): ?>
                            <a title="<?php echo e('Edit'); ?>" href="<?php echo e(route("admin.roles.edit", $role)); ?>" class="btn btn-sm btn-info"><i
                                    class="fa fas fa-edit"></i></a>
                            <form class="d-inline" method="post" action="<?php echo e(route("admin.roles.destroy", $role)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("DELETE"); ?>
                                <button title="<?php echo e('Delete'); ?>" type="submit" class="btn btn-sm btn-danger confirm"><i
                                        class="fa fas fa-trash"></i></button>
                            </form>
                        <?php endif; ?><?php /**PATH /var/www/controlpanel/storage/framework/views/073b6e6542e344682c3dfb791de649602eeed219.blade.php ENDPATH**/ ?>