
        function() {
            $('[data-toggle="popover"]').popover();

            $('.confirm').click(function(event) {
                var form =  $(this).closest("form");
                var name = $(this).data("delete-confirm");
                event.preventDefault();
                Swal.fire({
                    title: "<?php echo e(__('Are you sure you want to delete this record?')); ?>",
                    text: "<?php echo e(__('If you delete this, it will be gone forever.')); ?>",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonText: "<?php echo e(__("Yes, delete it!")); ?>",
                    cancelButtonText: "<?php echo e(__('No, cancel!')); ?>",
                    reverseButtons: false
                })
                    .then((e) => {
                        if (e.value) {
                            form.submit();
                        }
                    });
                });
            }<?php /**PATH /var/www/controlpanel/storage/framework/views/37e64def8e7eece4aeb2073f938834319133c50e.blade.php ENDPATH**/ ?>