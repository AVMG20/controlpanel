
      console.log(1)
        function() {
            console.log(1)
            $('confirm').click(function(event) {
                var form =  $(this).closest("form");
                var name = $(this).data("delete-confirm");
                event.preventDefault();
                Swal.fire({
                    title: "{{__('re you sure you want to delete this record?'}}",
                    text: "{{__('f you delete this, it will be gone forever.'}}",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonText: "{{__("Yes, delete it!")}}",
                    cancelButtonText: "{{__('o, cancel!'}}",
                    reverseButtons: false
                })
                    .then((e) => {
                        if (e.value) {
                            form.submit();
                        }
                    });
                });
            }